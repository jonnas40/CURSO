var num=1;
var player=1;
var gameid;
var user;
var pass;

function isPair(num) {
  if(num%2 == 0){
    return true;
  }
  else {
    return false;
  }
}

function register(username, password){

  let loginfo = {
    nick: username,
    pass: password
  }
  let tofetch = {
    method: 'post',
    body: JSON.stringify(loginfo)
  }
  fetch("http://twserver.alunos.dcc.fc.up.pt:8008/register",tofetch)
  .then(function(response){
    return response.json();
  })
  .then(function(data){
    if (data.error != null) {
      document.getElementById('logerror').style.display = "block";
    }
    else{
      document.getElementById('logname').innerHTML = username;
      document.getElementById('claname').innerHTML = "vs PC";
      config();
    }
  })
  .catch(function(err){
    console.log("Fetch Failed", err);
  })
}

function join(username, password, board_Size){
  document.getElementById('config').style.display = "none";
  let bsize = {
    rows: parseInt(board_Size.rows),
    columns: parseInt(board_Size.columns)
  }
  let joininfo = {
    group: 40,
    nick: username,
    pass: password,
    size: bsize
  }
  let tofetch = {
    method: 'post',
    body: JSON.stringify(joininfo)
  }
  fetch("http://twserver.alunos.dcc.fc.up.pt:8008/join",tofetch)
  .then(function(response){
    return response.json();
  })
  .then(function(data){
    if(data.error == null){
      gameid = data.game;
      document.getElementById('gameid').innerHTML = "gameid: " + String(gameid);
      document.getElementById('bdesist').setAttribute("onclick", "leave("+'gameid'+")");
      window.alert(gameid);
      var log = document.getElementById('log');
      while (log.firstChild){
        log.removeChild(log.firstChild);
      }
      update(gameid, username);
      makeBoard(board_Size.rows, board_Size.columns, 1);
    }
  })
  .catch(function(error) {
    console.log('Fetch failed', error);
  })
}

function update(gameid, username){
  let prevturn = "";
  var column;
  eventSource = new EventSource("http://twserver.alunos.dcc.fc.up.pt:8008/update?nick="+username+"&game="+gameid);
  eventSource.onmessage = function(event){
    u = JSON.parse(event.data);
    column = u.column;
    turn = u.turn;
    if(column != undefined && turn != document.getElementById('logname') && isPair(num)==true){
      jog2PutChip(column, turn);
      num++;
    }
    else if(column != undefined && isPair(num)==false){
      jog1PutChip(column, turn);
      num++
    }
    if (u.winner != undefined && num != 1){
      if(u.winner == username){
        writelog("lwin");
      }
      else{
        writelog("nwin");
      }
      analyze(0, 1);
      analyze(1, 1);
      winner();
      eventSource.close();
      num = 1;
    }
  }
  eventSource.onerror = function(err){
    console.log("EventSource error:", err);
  }
}

function notify(col, colu) {
  let noteinfo = {
    nick: username,
    pass: password,
    game: gameid,
    column: col
  }
  let tofetch = {
    method: 'post',
    body: JSON.stringify(noteinfo)
  }
  fetch("http://twserver.alunos.dcc.fc.up.pt:8008/notify", tofetch)
  .then(function(response){
    if(response.status == 200){
      return response.json();
    }
    else{
      writelog("impossible");
      return response.json();
    }
  })
  .catch(function(error) {
    console.log('Fetch failed', error);
  })
}

function leave(gameid){
  window.alert("LEAVE FFS");
  let leaveinfo = {
    nick: username,
    pass: password,
    game: gameid
  }
  let tofetch = {
    method:'post',
    body: JSON.stringify(leaveinfo)
  }
  fetch("http://twserver.alunos.dcc.fc.up.pt:8008/leave", tofetch)
  .then(function(response){
    return response.json();
  })
  .then(function(data){
    window.alert(data.winner);
    if(data.winner == undefined){           //Quando um jogador sai sem emparelhar
      writelog("leave");
      
    }

    else if(data.winner != document.getElementById('logname')){
      writelog("playleave");
    }

    else if(data.winner == document.getElementById('logname')){
      writelog("opleave");
    }

  })
  .catch(function(error){
    console.log('Fetch failed', error);
  })
}

function ranking(){
  let aux_size = {
    rows: parseInt(document.getElementById('nalt').value),
    columns: parseInt(document.getElementById('nlar').value)
  }
  let rankinfo = {
    size: aux_size
  }

  let tofetch = {
    method: 'post',
    body: JSON.stringify(rankinfo)
  }
  fetch("http://twserver.alunos.dcc.fc.up.pt:8008/ranking", tofetch)
  .then(function(response){
    return response.json();
  })
  .then(function(data){
    var body = document.getElementById('rankbody');
    while (body.firstChild){
      body.removeChild(body.firstChild);
    }
    const width = 3;
    const height = data.ranking.length;
    for (let i = 0; i < height; i++){
      var row = document.createElement('tr');
      var cell = document.createElement('td');
      cell.innerHTML = i+1;
      row.appendChild(cell);
      var cell = document.createElement('td');
      cell.innerHTML = data.ranking[i].nick;
      row.appendChild(cell);
      var cell = document.createElement('td');
      cell.innerHTML = data.ranking[i].victories;
      row.appendChild(cell);
      var cell = document.createElement('td');
      cell.innerHTML = data.ranking[i].games;
      row.appendChild(cell);
      body.appendChild(row);
    }
  })
  .catch(function(error){
    console.log('Fetch failed', error);
  })
}






function winner() {
  var columns = document.getElementById('game').childNodes;
  for (var i = 0; i < columns.length; i++) {
    columns[i].removeAttribute("onclick");
    columns[i].style.cursor = "auto";
  }
}
function jog2PutChip(column, turn){
  var columns = document.getElementById('game').childNodes;
  var j2_slots = columns[column].childNodes;
  for (let i = j2_slots.length-1; i>=0; i--){
    if(j2_slots[i].style.backgroundColor == "white"){
      j2_slots[i].style.backgroundColor = "#f4dc22";
      break;
    }
  }
}

function jog1PutChip(column, turn){
  var columns = document.getElementById('game').childNodes;
  var j1_slots = columns[column].childNodes;
  for (let i = j1_slots.length-1; i>=0; i--){
    if(j1_slots[i].style.backgroundColor == "white"){
      j1_slots[i].style.backgroundColor = "#ea3a3a";
      break;
    }
  }
}
